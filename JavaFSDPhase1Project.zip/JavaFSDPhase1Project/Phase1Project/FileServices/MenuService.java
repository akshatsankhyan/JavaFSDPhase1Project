package FileServices;

import FileUI.*;
public class MenuService {
    public static void setMenu()   {
        FileOptions file = new FileOptions();
        file.userInput();
    }
}
