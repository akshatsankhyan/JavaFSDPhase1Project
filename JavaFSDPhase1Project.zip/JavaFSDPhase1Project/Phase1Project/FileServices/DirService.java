package FileServices;

import FileSystem.*;
import java.io.*;

public class DirService {
    private static final Folder fileDir = new Folder();
    public static void showFiles() {
        fileDir.insertFiles();
        int flag = 0;
        for (File file : DirService.getFileDir().getListOfFiles()) {
            if(flag == 0){
                flag = 1;
                System.out.println("The Existing Files Are Listed Below : ");
            }
            System.out.println(file.getName());
        }
        if(flag == 0){
            System.out.println("Sorry No Existing Files Found.");
        }
    }
    public static Folder getFileDir() {
        return fileDir;
    }
    public static String Path() {
        return fileDir.path.toString();
    }
}
