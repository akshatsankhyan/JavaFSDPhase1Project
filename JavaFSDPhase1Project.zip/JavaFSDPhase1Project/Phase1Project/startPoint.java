import WelcomeScreen.WelcomeScreen;

public class startPoint {
    public static void main(String[] args)  {
        WelcomeScreen welcome = new WelcomeScreen();
        welcome.introMenuPage();
        welcome.userInput();
    }
}