package FileSystem;

import java.io.*;
import java.nio.file.*;
import java.util.*;

public class Folder {
    public String name = "FileStorage/";
    private final ArrayList<File> files = new ArrayList<>();

    public Path path = FileSystems.getDefault().getPath(name).toAbsolutePath();
    File prevFiles = path.toFile();

    public void insertFiles() {
        File[] presentFiles = prevFiles.listFiles();
        files.clear();
        if (presentFiles != null) {
            for (File presentFile : presentFiles)
                if (presentFile.isFile())
                    files.add(presentFile);
        }

        Collections.sort(files);
    }
    public ArrayList<File> getListOfFiles() {
        insertFiles();
        return files;
    }
}
