package FileSystem;

import java.util.Scanner;

public interface Screen {

    Scanner sc = new Scanner(System.in);
    void menuOptions();
    void NavigateOption(int choice);
    void userInput();
}
