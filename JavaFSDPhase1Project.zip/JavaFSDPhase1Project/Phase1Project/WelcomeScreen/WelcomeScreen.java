package WelcomeScreen;

import FileServices.*;
import FileSystem.*;
import java.util.*;

public class WelcomeScreen implements Screen {

    final String productName = "*!*!*!*!*!*!*!*!*!* PRESENTING YOU APPLICATION LOCKEDME.COM BY LOCKERS PVT.LTD. *!*!*!*!*!*!*!*!*!*";
    final String developerName = "Developed By -> AKSHAT SANKHYAN";

    private final ArrayList<String> optionList = new ArrayList<>();


    public WelcomeScreen() {
        optionList.add("-> Press 1 To Show Existing Files");
        optionList.add("-> Press 2 To Show File Options Menu");
        optionList.add("-> Press 3 To Quit The Application");
    }
    public void introMenuPage() {
        System.out.println();
        System.out.println(productName);
        System.out.println("\t\t\t\t\t\t\t\t" + developerName);
        System.out.println("\t\t\t===========================================================================");
        System.out.println();
        System.out.println("Root Directory : " + DirService.getFileDir().name);
    }
    @Override
    public void menuOptions() {
        System.out.println();
        System.out.println("Main Menu");
        for (String str : optionList)  {
            System.out.println(str);
        }
    }
    @Override
    public void NavigateOption(int choice) {
        switch(choice) {
            case 1:
                DirService.showFiles();
                break;
            case 2:
                MenuService.setMenu();
                break;
            case 3:
                System.out.println("\n Thank You For Using `LOCKEDME.COM`.Hope You Liked Our Application. ");
                break;
            default:
                System.out.println("Please Enter Valid Option ");
                break;
        }
    }
    @Override
    public void userInput() {
        int val = 0;
        char o;
        while(val != 3) {
            this.menuOptions();
            System.out.print("Enter Your Choice : ");
            o = sc.next().charAt(0);
            val = (int)o - 48;
            this.NavigateOption(val);
        }
    }
}
