package FileUI;

import java.io.*;
import java.nio.file.Path;
import java.util.*;
import FileServices.*;

public class FileOperations {

    Scanner sc = new Scanner(System.in);
    String filename;
    char ch;

    public void AddFile()   {
        System.out.print("Enter the File Name you want to create along with the extension : ");
        filename = sc.nextLine();

        File file = new File(DirService.Path() + "/" + filename);
        try {
            boolean flag = file.createNewFile();
            if(flag) {
                System.out.println("File with name " + filename + " is created!!!");
                System.out.println("Do you want to write something in this File ? Press y for Yes and n for No.");
                ch = sc.next().charAt(0);
                if(ch == 'Y' || ch == 'y') {
                    System.out.print("Enter the content you want to write in file : ");
                    sc.nextLine();
                    String fileData = sc.nextLine();
                    try {
                        FileWriter writeData = new FileWriter(DirService.Path() + "/" + filename);
                        writeData.write(fileData);
                        System.out.println("Data is successfully written in the file.");
                        writeData.close();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
            else System.out.println("Not Able to create " + filename + ". Try Again with another name");
        } catch(Exception e)	{
            e.printStackTrace();
        }
    }
    public void DeleteFile()    {
        System.out.print("Enter the File Name you want to delete along with the extension : ");
        filename = sc.nextLine();

        File file = new File(DirService.Path() + "/" + filename);
        try {
            boolean flag = file.delete();
            if(flag) System.out.println("File with name " + filename + " is deleted!!!");
            else System.out.println("Not Able to delete " + filename + ". Try Again");

        } catch(Exception e)	{
            e.printStackTrace();
        }
    }
    public void SearchFile() {
        boolean isFound = false;

        System.out.print("Enter the File Name you want to search along with the extension : ");
        String fileName = sc.nextLine();
        System.out.println("You are searching for a file named: " + fileName);

        Path path = DirService.getFileDir().path;
        File prevFiles = path.toFile();

        File[] directoryFiles = prevFiles.listFiles();

        if (directoryFiles != null) {
            for (File directoryFile : directoryFiles)
                if (directoryFile.getName().equals(fileName)) {
                    System.out.println("File named " + fileName + " Found");
                    isFound = true;
                }
        }
        if (!isFound)
            System.out.println("!!!FILE NOT FOUND!!!");
    }
}
