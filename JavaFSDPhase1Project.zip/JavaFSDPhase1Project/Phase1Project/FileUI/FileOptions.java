package FileUI;

import FileSystem.*;
import java.util.*;

public class FileOptions implements Screen {

    private final ArrayList<String> options = new ArrayList<>();
    FileOperations file = new FileOperations();

    public FileOptions() {
        options.add("-> Press 1 To Add a File");
        options.add("-> Press 2 To Delete a File");
        options.add("-> Press 3 To Search a File");
        options.add("-> Press 4 To Return To Menu");

    }
    @Override
    public void menuOptions() {
        System.out.println();
        System.out.println("!!!File Options Menu!!!");
        for (String str : options) {
            System.out.println(str);
        }
    }
    @Override
    public void NavigateOption(int option) {
        switch (option) {
            case 1:
                file.AddFile();
                break;
            case 2:
                file.DeleteFile();
                break;
            case 3:
                file.SearchFile();
                break;
            default:
                System.out.println("Returning To Main Menu.......");
                break;
        }
    }
    @Override
    public void userInput() {
        char ch;
        int val = 0;
        while (val != 4) {
            this.menuOptions();
            System.out.print("Enter Your Choice : ");
            ch = sc.next().charAt(0);
            val = (int)ch - 48;
            this.NavigateOption(val);
        }
    }
}